# Dossier scope and common assumptions

FICTIONAL teaching source — original Session 2 EV dossier; no real paper or measured hardware result.
Source: EV-S01
Date: 2026-10-01
Author: fictional Depot Methods Desk
Provenance: course issue #181, original public dossier v1
Reporting relationship: scope note
Experiments: none
Families: none
Supersedes: none

## EV-S01:P01

This fictional catalogue contains exactly three candidate methods: Slot Ledger (slot-ledger), Queue Repair (queue-repair), and Slot Ledger Private (private-ledger). Only Slot Ledger and Queue Repair model limited shared charger capacity. The private edition is a title distractor, not another shared-capacity method.

## EV-S01:P02

Both shared-capacity methods assume deterministic, known legs, travel times, energy use, tariffs and charger availability for the whole day. Both use 30-minute slots, require each charge to fit wholly inside a depot wait, and assume lossless charging at constant power bounded by the truck and charger ratings. These are modelling assumptions, not evidence about uncertain demand.

## EV-S01:P03

Every fictional timing below uses EVBench R1: one thread on the same illustrative reference CPU, including model construction and search until the first complete feasible daily plan passes coverage, sequence, charging, maintenance and state-of-charge checks. A solve need not prove optimality. The acceptance limit is at most 60 seconds; it is not a forecast for student hardware.

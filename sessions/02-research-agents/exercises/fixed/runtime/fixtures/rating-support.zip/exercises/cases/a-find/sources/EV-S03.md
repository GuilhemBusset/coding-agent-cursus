# Queue Repair: shared-depot scheduling

FICTIONAL teaching source — original Session 2 EV dossier; no real paper or measured hardware result.
Source: EV-S03
Date: 2026-10-03
Author: fictional Depot Methods Desk
Provenance: course issue #181, original public dossier v1
Reporting relationship: method note
Experiments: none
Families: none
Supersedes: none

## EV-S03:P01

Queue Repair (queue-repair) fixes candidate truck routes for a repair pass, then allocates charging against a per-depot, per-type, per-slot occupancy ledger. A slot is usable only while its count is below the finite charger count. Conflicts move to another valid waiting slot or trigger leg cancellation and route rebuilding; an unresolved conflict is never returned as feasible.

## EV-S03:P02

Queue Repair assumes the same known deterministic inputs and 30-minute whole-wait, lossless constant-power charging as EV-S01:P02. It checks coverage, deadheads and return home, truck and charger power, maintenance, battery bounds and final state of charge after repair or cancellation. Fixed candidate routes and repair-or-cancel make this a feasible-plan heuristic, with no claim of global cost optimality.

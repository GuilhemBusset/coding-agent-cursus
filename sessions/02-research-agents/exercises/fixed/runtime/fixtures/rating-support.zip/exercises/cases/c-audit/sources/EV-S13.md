# EV-S13 — Audit protocol

Fictional course data, issue #182. Date: 2026-11-14.

## EV-S13:P01

This original fictional numerical extension uses method A (audit-a) as the daily-cost baseline and method B (audit-b) as the candidate. Both use the deterministic P01 shared-charger model and the same cost objective: penalties, charging and degradation, and deadheading. The costs are fictional cost units, not measured currency. We claim method B is 20% cheaper on the feasible paired subset, not on all logged runs.

## EV-S13:P02

Pair only identical instance_id and run_id, represented by one pair_id. Require exactly one row of each method and both feasible=true. Reject ambiguous duplicate method rows. Exclude every row of an incomplete or infeasible pair; an infeasible cheap objective is not a valid daily plan. The CSV lists independent method executions within each paired deterministic day; experiment IDs identify executions, and EV-F-C identifies the comparison family.

## EV-S13:P03

Use the sum of method A costs as the denominator: reduction_ratio=(sum_A-sum_B)/sum_A; reduction_percent=100*reduction_ratio. Do not average per-pair percentages or divide by sum_B. Compare the percentage in percent with inclusive absolute tolerance 0.01 percentage points and relative tolerance zero. Costs, row identities, feasibility and pair membership are exact; ratio has tolerance 0.0001.

